INSERT INTO cidade (id, nome) VALUES (1,'Assis');
INSERT INTO cidade (id, nome) VALUES (2,'Cornelio Procopio');