package com.cp.rest.configuration;

import jakarta.ws.rs.core.Application;
import jakarta.ws.rs.ApplicationPath;

@ApplicationPath("rest")
public class CPApplication extends Application {
    
}
